package com.qr.generation.leopex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LeopexApplication {

	public static void main(String[] args) {
		SpringApplication.run(LeopexApplication.class, args);
	}

}
