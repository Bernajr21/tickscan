package com.qr.generation.leopex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LeopexApplicationTests {

	@Test
	void contextLoads() {
	}

}
